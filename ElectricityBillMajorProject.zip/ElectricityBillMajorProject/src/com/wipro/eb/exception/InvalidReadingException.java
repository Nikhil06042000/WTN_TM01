package com.wipro.eb.exception;

public class InvalidReadingException extends Exception {
	public String toString(){
		return "You Entered Invalid Readings";
	}
}
