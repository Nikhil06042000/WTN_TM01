package com.wipro.eb.exception;

public class InvalidConnectionException extends Exception {
	public String toString(){
		return "You Entered Invalid Connection Type";
	}
}
